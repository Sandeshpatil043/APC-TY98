from django import forms
from django.contrib.auth import authenticate
from django.contrib.auth.models import User

from .validators import validate_email, validate_password, validate_username


class RegisterForm(forms.Form):
    username = forms.CharField(max_length=20, validators=[validate_username])
    email = forms.CharField(validators=[validate_email])
    password = forms.CharField(widget=forms.PasswordInput, validators=[validate_password])
    confirm_password = forms.CharField(widget=forms.PasswordInput)

    def clean_username(self):
        username = self.cleaned_data["username"]
        if User.objects.filter(username__iexact=username).exists():
            raise forms.ValidationError("This username is already taken.")
        return username

    def clean_email(self):
        email = self.cleaned_data["email"]
        if User.objects.filter(email__iexact=email).exists():
            raise forms.ValidationError("This email is already registered.")
        return email

    def clean(self):
        cleaned = super().clean()
        if cleaned.get("password") and cleaned.get("password") != cleaned.get("confirm_password"):
            self.add_error("confirm_password", "Passwords do not match.")
        return cleaned


class LoginForm(forms.Form):
    username = forms.CharField(max_length=20, validators=[validate_username])
    password = forms.CharField(widget=forms.PasswordInput)

    def clean(self):
        cleaned = super().clean()
        username, password = cleaned.get("username"), cleaned.get("password")
        if username and password:
            user = authenticate(username=username, password=password)
            if user is None:
                raise forms.ValidationError("Invalid username or password.")
            cleaned["user"] = user
        return cleaned

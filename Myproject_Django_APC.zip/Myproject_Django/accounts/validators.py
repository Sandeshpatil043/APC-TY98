import re

from django.core.exceptions import ValidationError

USERNAME_REGEX = re.compile(r"^[A-Za-z][A-Za-z0-9_]{3,19}$")

EMAIL_REGEX = re.compile(r"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$")

# Password: min 8 chars, at least one lowercase, uppercase, digit and special char
PASSWORD_REGEX = re.compile(
    r"^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&#])[A-Za-z\d@$!%*?&#]{8,}$"
)


def validate_username(value):
    if not USERNAME_REGEX.match(value):
        raise ValidationError(
            "Username must be 4-20 characters, start with a letter, and contain "
            "only letters, digits or underscores."
        )


def validate_email(value):
    if not EMAIL_REGEX.match(value):
        raise ValidationError("Enter a valid email address (e.g. name@example.com).")


def validate_password(value):
    if not PASSWORD_REGEX.match(value):
        raise ValidationError(
            "Password must be at least 8 characters and include an uppercase letter, "
            "a lowercase letter, a digit and a special character (@$!%*?&#)."
        )
